package connection;

import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import algorithme.Algorithme;

//We import java.io to be able to read from the command line
import java.io.*;

import oracle.jdbc.pool.OracleDataSource;
import donnees.*;
public class ConnectToBDD {
	
	
	public static Statement openConnection() throws SQLException {
		OracleDataSource ods = new OracleDataSource();

		Connection conn = null;

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		ods.setURL(url);
		ods.setUser("mosca");
		ods.setPassword("azerty");
		conn = ods.getConnection();
		return conn.createStatement();
	}
	
	public static void closeConnection(ResultSet rset, Statement stmt, Connection conn) throws SQLException {
	     if(rset!=null) rset.close();
	     if(stmt!=null) stmt.close();
	     if(conn!=null) conn.close();
	} 
}