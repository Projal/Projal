package connection;

import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;

public class ConnectToBDD {
	
	
	public static Statement openConnection() throws SQLException {
		OracleDataSource ods = new OracleDataSource();

		Connection conn = null;

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		ods.setURL(url);
		ods.setUser("idriss");
		ods.setPassword("crazy13ilsM");
		conn = ods.getConnection();
		return conn.createStatement();
	}
	
	public static void closeConnection(ResultSet rset, Statement stmt, Connection conn) throws SQLException {
	     if(rset!=null) rset.close();
	     if(stmt!=null) stmt.close();
	     if(conn!=null) conn.close();
	} 
}