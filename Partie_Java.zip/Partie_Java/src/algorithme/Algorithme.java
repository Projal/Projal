package algorithme;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectToBDD;
import donnees.*;

public class Algorithme {
	
	public static List<Medicament> Algo(List<Medicament> medics, Patient pat) throws SQLException {
		boolean test = true;
		List<Medicament> resultat = new ArrayList<Medicament>();
		List<Molecule> temp = new ArrayList<Molecule>();
		List<Molecule> premRes = new ArrayList<Molecule>();
		List<Molecule> resMol = new ArrayList<Molecule>();
		
		for(Medicament medic : medics)
			if(!temp.contains(medic.getMolecule())) {
				temp.add(medic.getMolecule());
			}
		
		for(Medicament medic : medics) {
			premRes = conflitInterne(medic, temp, pat);
			if(premRes.isEmpty()) {
				resultat.add(medic);
			}
			else {
				System.out.println(false);
				test = false;
			}
			for(Molecule premMol : premRes) {
				if(!resMol.contains(premMol))
					resMol.add(premMol);
			}
		}
		if(test)
			return medics;
		for(Molecule molec : resMol)
			for(Medicament medic : molec.getMedicaments()) {
					resultat.add(medic);
				}
		return supprimer_doublons(resultat);
	}

	private static List<Molecule> conflitInterne(Medicament medic, List<Molecule> molecs, Patient pat) throws SQLException {
		List<Molecule> resultat = new ArrayList<Molecule>();
		List<String> strtmp = new ArrayList<String>();
		List<Molecule> temp = new ArrayList<Molecule>();
		for(Molecule mol : molecs) {
			if(mol.getConflits().contains(medic.getMolecule().getNom())) {
				for(Molecule soluce : medic.getMaladie().getMolecules())
					temp.add(soluce);
			}
		}
		
		for(Molecule mol : temp)
			strtmp.add(mol.getNom());
		ResultSet res = ConnectToBDD.getStmt().executeQuery("SELECT NOM_MOLEC FROM SOIGNE so, MOLECULE mol WHERE id_maladie = " + medic.getMaladie().getId() + "AND so.ID_MOLEC = mol.ID_MOLEC");
		while(res.next()) {
			if(!strtmp.contains(res.getString(1)) && !strtmp.isEmpty())
				strtmp.add(res.getString(1));
		}
		for(String str : strtmp)
			temp.add(new Molecule(str, ConnectToBDD.getStmt()));
		boolean test = false;
		for(Molecule sol : temp) {
			for(Molecule mol : molecs)
				if(sol.getConflits().contains(mol.getNom())) {
					test = true;
				}
			if(!test) {
				resultat.add(sol);
			}
			test = false;
		}
		
		temp = new ArrayList<Molecule>();
		for(Molecule mol : resultat)
			if(estConflit(pat, mol))
				temp.add(mol);
		resultat.removeAll(temp);
		return resultat;
	}

	private static boolean estConflit(Patient patient, Molecule molecule) {
		if(molecule.getConflits().contains(patient.getCategorieAge())) {
			return true;
		}
		for(ContreIndication contrInd : patient.getContreIndications()) {
			if(molecule.getConflits().contains(contrInd.getNom())) {
				return true;
			}
		}
		for(Traitement trait : patient.getTraitements()) {
			if(!trait.fini()) {
				for(Medicament medic : trait.getListMedicaments()) {
					if(molecule.getConflits().contains(medic.getMolecule().getNom())) {
						return true;
					}
				}
			}
		}
		return false;
	}	
	
	
	private static List<Medicament> supprimer_doublons(List<Medicament> medics) {
		boolean test = false;
		List<Medicament> result = new ArrayList<Medicament>();
		for(Medicament medic : medics) {
			for(Medicament resMed : result)
				if(medic.getNom().equals(resMed.getNom()))
						test = true;
			if(!test)
				result.add(medic);
			test = false;
		}
		return result;
	}
	
	
	
}
