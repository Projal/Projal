package algorithme;

import java.util.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectToBDD;
import donnees.*;

public class MainAlgo {

	public static void main(String[] args) throws SQLException, ParseException {
		ConnectToBDD.openConnection();
		Statement stmt = ConnectToBDD.getStmt();
		Patient pat = new Patient(1, "Albert", "Bernard", 3);
		List<Medicament> medics = new ArrayList<Medicament>();
		List<String> nom_medics = new ArrayList<String>();
		Medicament medic = new Medicament(stmt, "AZANTAC 150 mg");
		Medicament medic2 = new Medicament(stmt,"CELECTOL 200 mg");
		medics.add(medic);
		medics.add(medic2);
		nom_medics.add(medic.getNom());
		nom_medics.add(medic2.getNom());
		Traitement trait = new Traitement(new Date (System.currentTimeMillis()), new Date(System.currentTimeMillis()+10000000), nom_medics, 4, stmt);
		List<Medicament> resultat = Algorithme.Algo(medics, pat);
		for(Medicament medicament : resultat)
			System.out.println(medicament.getNom());
	}

}
