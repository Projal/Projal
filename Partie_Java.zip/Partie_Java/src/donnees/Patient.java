package donnees;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Patient {
	private String nom;
	private String prenom;
	private int categorieAge;
	private long id;
	private List<ContreIndication> contreIndications;
	private List<Traitement> traitements;
	
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	
	
	public int convertCategorieAge(String categorieAge){
		if(categorieAge.equals("nourrisson"))
			return 1;
		if(categorieAge.equals("enfant"))
			return 2;
		if(categorieAge.equals("adulte"))
			return 3;
		return 4;
	}
	
	
	public String getCategorieAgeString() {
		if(categorieAge == 1)
			return "Nourrisson";
		if(categorieAge == 2)
			return "Enfant";
		if(categorieAge == 3)
			return "Adulte";
		return "Senior";
	}
	public void setCategorieAge(int categorieAge) {
		this.categorieAge = categorieAge;
	}
	
	public long getId() {
		return id;
	}
	public List<ContreIndication> getContreIndications() {
		return contreIndications;
	}
	public List<Traitement> getTraitements() {
		return traitements;
	}
	
	public boolean addContreIndication(ContreIndication newContreIndication) {
		return contreIndications.add(newContreIndication);
	}
	
	public boolean removeContreIndication(String nomContreIndication) {
		for(ContreIndication contreIndication : contreIndications)
			if(contreIndication.getNom() == nomContreIndication){
				contreIndications.remove(contreIndication);
				return true;
			}
		return false;
	}
	
	public Patient(Statement stmt, long id, String nom, String prenom, int categ) throws SQLException {
		this.nom = nom;
		this.prenom = prenom;
		this.id = id;
		this.categorieAge = categ;
		if(!patientExistant(id, stmt))
			stmt.executeUpdate("INSERT INTO PATIENT VALUES("+id+",'"+nom+"','"+prenom+"',"+categ+")");
	}
	
	public Patient(long id, String nom, String prenom, int cat) {
		this.nom = nom;
		this.prenom = prenom;
		this.id = id;
		this.categorieAge = cat;
		contreIndications = new ArrayList<ContreIndication>();
		traitements = new ArrayList<Traitement>();
	}
	
	public boolean patientExistant(long id, Statement stmt)throws SQLException  {
		return stmt.executeQuery("SELECT id_patient FROM PATIENT where "+id+" = id_patient").next();
	}
	
	public boolean addTraitement(Traitement newTraitement) {
		return traitements.add(newTraitement);
	}
}
