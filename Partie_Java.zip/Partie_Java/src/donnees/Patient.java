package donnees;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectToBDD;

public class Patient {
	private String nom;
	private String prenom;
	private String categorieAge;
	private long id;
	private List<ContreIndication> contreIndications;
	private List<Traitement> traitements;
	
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	
	
	public static int convertCategorieAge(String categorieAge){
		if(categorieAge.equals("Nourrisson"))
			return 1;
		if(categorieAge.equals("Enfant"))
			return 2;
		if(categorieAge.equals("Adulte"))
			return 3;
		return 4;
	}
	
	
	public static String getCategorieAgeString(int categorieAge) {
		if(categorieAge == 1)
			return "Nourrisson";
		if(categorieAge == 2)
			return "Enfant";
		if(categorieAge == 3)
			return "Adulte";
		return "Senior";
	}
	public void setCategorieAge(int categorieAge) {
		this.categorieAge = getCategorieAgeString(categorieAge);
	}
	
	public long getId() {
		return id;
	}
	public List<ContreIndication> getContreIndications() {
		return contreIndications;
	}
	public List<Traitement> getTraitements() {
		return traitements;
	}
	
	public boolean addContreIndication(ContreIndication newContreIndication) {
		return contreIndications.add(newContreIndication);
	}
	
	public boolean removeContreIndication(String nomContreIndication) {
		for(ContreIndication contreIndication : contreIndications)
			if(contreIndication.getNom() == nomContreIndication){
				contreIndications.remove(contreIndication);
				return true;
			}
		return false;
	}
	
	public Patient(Statement stmt, long id, String nom, String prenom, String categ) throws SQLException {
		this.nom = nom;
		this.prenom = prenom;
		this.id = id;
		this.categorieAge = categ;
		if(patientExistant(id, stmt) == -1)
			stmt.executeUpdate("INSERT INTO PATIENT VALUES("+id+",'"+nom+"','"+prenom+"',"+convertCategorieAge(categ)+")");
	}
	
	public Patient(long id, String nom, String prenom, String cat) throws SQLException {
		this.nom = nom;
		this.prenom = prenom;
		this.id = id;
		this.categorieAge = cat;
		contreIndications = new ArrayList<ContreIndication>();
		remplirContreIndication();
		traitements = new ArrayList<Traitement>();
		remplirTraitement();
	}
	
	
	private void remplirContreIndication() throws SQLException{
		List<Integer> listId = new ArrayList<Integer>();
		ResultSet rset = ConnectToBDD.getStmt().executeQuery("SELECT ID_CONTR FROM ESTASSOCIE WHERE ID_PATIENT = "+id);
		while(rset.next())
			listId.add(rset.getInt(1));
		List<String> listNomContreIndic = new ArrayList<String>();
		for(Integer idContr : listId) {
			rset = ConnectToBDD.getStmt().executeQuery("SELECT NOM_CONTR FROM CONTRE_INDICATION WHERE ID_CONTR = "+idContr);
			rset.next();
			listNomContreIndic.add(rset.getString(1));
		}
		for(String nomContreIndic : listNomContreIndic) {
			contreIndications.add(new ContreIndication(ConnectToBDD.getStmt(),nomContreIndic));
		}
	}
	
	private void remplirTraitement() throws SQLException{
		ResultSet rset = ConnectToBDD.getStmt().executeQuery("SELECT ID_TRAIT FROM PRESCRIT WHERE ID_PATIENT = "+id);
		List<Integer> listId = new ArrayList<Integer>();
		while(rset.next())
			listId.add(rset.getInt(1));
		for(int traitId : listId) {
			traitements.add(new Traitement(ConnectToBDD.getStmt(),traitId));
		}
	}
	
	public static int patientExistant(long id, Statement stmt)throws SQLException  {
		ResultSet res = stmt.executeQuery("SELECT id_patient FROM PATIENT where "+id+" = id_patient");
		if(res.next())
			return res.getInt(1);
		return -1;
	}
	
	public boolean addTraitement(Traitement newTraitement) {
		return traitements.add(newTraitement);
	}
	
	public void setNom(String string) {
		nom = string;
	}
	
	public void setPrenom(String string) {
		prenom = string;
	}
	
	public void setId(long id) {
		this.id = id;
	}
	public String getCategorieAge() {
		return categorieAge;
	}
}
 