package donnees;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import connection.ConnectToBDD;

public class Maladie {
	private int id;
	private String nom;
	private List<Molecule> molecules;
	
	public Maladie(Statement stmt, String nom) throws SQLException {
		if(!maladieExistant(stmt, nom)) {
			System.out.println("ERREUR: Maladie non existant " + nom);
			return;
		}
		this.nom = nom;
		List<String> list = new ArrayList<String>();
		ResultSet resMal = stmt.executeQuery("SELECT ID_MALADIE FROM MALADIE WHERE NOM_MALADIE = '"+nom+"'");
		resMal.next();
		id = resMal.getInt(1);
			
		molecules = new ArrayList<Molecule>();
		ResultSet resMol = stmt.executeQuery("SELECT NOM_MOLEC FROM MOLECULE mol, SOIGNE so WHERE mol.ID_MOLEC = so.ID_MOLEC AND ID_MALADIE = "+id);
		while(resMol.next()){
			list.add(resMol.getString(1));
		}
		for(String molec : list)
			molecules.add(new Molecule(molec,stmt));
	}
	
	public Maladie(String nom, int id) {
		this.id = id;
		this.nom = nom;
	}

	public int getId() {
		return id;
	}
	
	public String getNom() {
		return nom;
	}
	public List<Molecule> getMolecules() {
		return molecules;
	}
	
	public static boolean maladieExistant(Statement stmt, String nom) throws SQLException {
		ResultSet result = stmt.executeQuery("SELECT NOM_MALADIE FROM MALADIE WHERE NOM_MALADIE = '" +nom+ "'");
		return result.next();
	}

	public static List<Maladie> getMaladies(Statement stmt) throws SQLException {
		List<Maladie> maladies = new ArrayList<Maladie>();
		ResultSet resId = stmt.executeQuery("SELECT ID_MALADIE FROM MALADIE");
		List<Integer> ids = new ArrayList<Integer>();
		ResultSet resMal;
		while (resId.next()) {
			ids.add(resId.getInt(1));
		}
		for (Integer id : ids) {
			resMal = stmt.executeQuery("SELECT NOM_MALADIE FROM MALADIE WHERE ID_MALADIE = " + id);
			if(resMal.next()) 
				maladies.add(new Maladie(stmt,resMal.getString(1)));
		}
		return maladies;
	}
}