package solution;

import java.net.URL;
import java.util.ResourceBundle;


import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
public class SolutionController implements Initializable {
	
	@FXML
    private TextArea text_contreindic;
	
	 @FXML
	 private TableView<Medicament> tab_medic;

    @FXML
    private TableColumn<Medicament, String> nom_molCol;

    @FXML
    private TableColumn<Medicament, String> nom_medicCol;


    
	private final ObservableList<Medicament> data = FXCollections.observableArrayList(
			new Medicament("PARACETAMOL", "DOLIPRANE"),
			new Medicament("PARACETAMOL", "DOLIPRANE"),
			new Medicament("PARACETAMOL", "DOLIPRANE"),
			new Medicament("ANASTROZOLE","ARIMIDEX 1 mg -" ));

    
	public static class Medicament {
		private final SimpleStringProperty nom_mol;
		private final  SimpleStringProperty nom_medic;
		
		private Medicament(String medic, String mol) {
			this.nom_mol = new SimpleStringProperty(mol);
			this.nom_medic = new SimpleStringProperty(medic);
		}
		
		public String getNom_medic() {
			return nom_medic.get();
		}
		
		public void setNom_medic(String  medic) {
			nom_medic.set(medic);
		}
		
		public String getNom_mol() {
			return nom_mol.get();
		}
		
		public void setNom_mol(String mol) {
			nom_mol.set(mol);
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		nom_molCol.setMinWidth(50);
	    nom_medicCol.setMinWidth(50);
	    
     	nom_molCol.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom_mol"));
     	nom_medicCol.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom_medic"));

		tab_medic.setItems(data);
		}

    @FXML
    private AnchorPane background;
}