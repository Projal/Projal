package accueil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import connection.ConnectToBDD;
import donnees.Medecin;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class AccueilController implements Initializable {

	@FXML
    private Button rand;

	@FXML
    private TextField text_search;

    @FXML
    private Label label;
    

    @FXML
    private Button search;

    @FXML
    private TableView<Person> table;

    @FXML
    private TableColumn<Person, String> lastNameCol;

    @FXML
    private TableColumn<Person, String> firstNameCol;
    
    @FXML
    private TableColumn<Person, String> ageCol;

    @FXML
    private TableColumn<Person, String> secuCol;
	    
	private ObservableList<Person> data = FXCollections.observableArrayList();

	public static class Person {

		private final SimpleStringProperty firstName;
		private final SimpleStringProperty lastName;
		private final SimpleStringProperty age;
		private final SimpleStringProperty secu;


		private Person(String fName, String lName, String Age, String Nsecu) {
			this.firstName = new SimpleStringProperty(fName);
			this.lastName = new SimpleStringProperty(lName);
			this.age = new SimpleStringProperty(Age);
			this.secu = new SimpleStringProperty(Nsecu);
		}

		public String getFirstName() {
			return firstName.get();
		}

		public void setFirstName(String fName) {
			firstName.set(fName);
		}

		public String getLastName() {
			return lastName.get();
		}

		public void setLastName(String fName) {
			lastName.set(fName);
		}

		public String getAge() {
			return age.get();
		}

		public void setAge(String num) {
			age.set(num);
		}


		public String getSecu() {
			return secu.get();
		}

		public void setSecu(String num) {
			secu.set(num);
		}

	}
	
	private void fillTable() throws SQLException {
		Statement stmt = ConnectToBDD.openConnection();
		Medecin med = new Medecin(stmt, 2);
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		firstNameCol.setMinWidth(100);
	    lastNameCol.setMinWidth(100);
	    ageCol.setMinWidth(100);
	    secuCol.setMinWidth(250);
	     
     	firstNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
		lastNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
		ageCol.setCellValueFactory(new PropertyValueFactory<Person, String>("age"));
		secuCol.setCellValueFactory(new PropertyValueFactory<Person, String>("secu"));
		
		table.setItems(data);
		}
	
	@FXML
    void searchButton(ActionEvent event) {
			
    }

}