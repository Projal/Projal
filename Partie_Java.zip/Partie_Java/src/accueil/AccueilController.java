package accueil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ResourceBundle;

import connection.ConnectToBDD;
import donnees.Medecin;
import donnees.Patient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

public class AccueilController extends Controller implements Initializable {


    @FXML
    private AnchorPane background;
	
	@FXML
    private Button newordo_button;

	@FXML
    private TextField text_search;

    @FXML
    private Label label;
    
    @FXML
    private Button search;
    
    @FXML
    private Button new_patient;

    @FXML
    private TableView<Patient> table;

    @FXML
    private TableColumn<Patient, String> lastNameCol;

    @FXML
    private TableColumn<Patient, String> firstNameCol;
    
    @FXML
    private TableColumn<Patient, String> ageCol;

    @FXML
    private TableColumn<Patient, String> secuCol;
	    
	private ObservableList<Patient> data = FXCollections.observableArrayList();
	
	public static Patient pers;
	
	public static boolean fromAccueil;
	
	private void fillTable() throws SQLException {
	    Statement stmt = ConnectToBDD.getStmt();
		Medecin med = new Medecin(stmt, SampleController.id);
		List<Patient> pats = med.getPatients(stmt);
		for(Patient pat : pats) {
			data.add(new Patient(pat.getId(), pat.getNom(), pat.getPrenom(), (pat.getCategorieAge())));
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			ConnectToBDD.openConnection();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		fromAccueil = true;
		NewPatientController.fromPatient = false;
		try {
			fillTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		firstNameCol.setMinWidth(200);
	    lastNameCol.setMinWidth(200);
	    ageCol.setMinWidth(200);
	    secuCol.setMinWidth(200);
	     
     	firstNameCol.setCellValueFactory(new PropertyValueFactory<Patient, String>("prenom"));
		lastNameCol.setCellValueFactory(new PropertyValueFactory<Patient, String>("nom"));
		ageCol.setCellValueFactory(new PropertyValueFactory<Patient, String>("categorieAge"));
		secuCol.setCellValueFactory(new PropertyValueFactory<Patient, String>("id"));
		
		table.setItems(data);
	}
	
	@FXML
	public void newOrdo() throws IOException {
		if(!table.getSelectionModel().getSelectedCells().isEmpty()) {
			AccueilController.pers = table.getSelectionModel().getSelectedItem();
			nextScene(background, "newordo.fxml");
		}
	}
	
	@FXML
    void searchButton(ActionEvent event) throws IOException {
		for(Patient pers : data)
			if(pers.getPrenom().toLowerCase().equals(text_search.getText().toLowerCase()))
				table.getSelectionModel().select(pers);
    }
	
	@FXML
	public void newPatient() throws IOException {
		nextScene(background, "newpatient.fxml");
	}
}