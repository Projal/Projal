package accueil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ResourceBundle;

import connection.ConnectToBDD;
import donnees.Medecin;
import donnees.Patient;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AccueilController implements Initializable, Controller {

	@FXML
    private Button newordo_button;

	@FXML
    private TextField text_search;

    @FXML
    private Label label;
    
    @FXML
    private Button search;

    @FXML
    private TableView<Person> table;

    @FXML
    private TableColumn<Person, String> lastNameCol;

    @FXML
    private TableColumn<Person, String> firstNameCol;
    
    @FXML
    private TableColumn<Person, String> ageCol;

    @FXML
    private TableColumn<Person, String> secuCol;
	    
	private ObservableList<Person> data = FXCollections.observableArrayList();

	public static class Person {

		private final SimpleStringProperty firstName;
		private final SimpleStringProperty lastName;
		private final SimpleStringProperty age;
		private final SimpleStringProperty secu;


		private Person(String fName, String lName, String Age, String Nsecu) {
			this.firstName = new SimpleStringProperty(fName);
			this.lastName = new SimpleStringProperty(lName);
			this.age = new SimpleStringProperty(Age);
			this.secu = new SimpleStringProperty(Nsecu);
		}

		public String getFirstName() {
			return firstName.get();
		}

		public void setFirstName(String fName) {
			firstName.set(fName);
		}

		public String getLastName() {
			return lastName.get();
		}

		public void setLastName(String fName) {
			lastName.set(fName);
		}

		public String getAge() {
			return age.get();
		}

		public void setAge(String num) {
			age.set(num);
		}


		public String getSecu() {
			return secu.get();
		}

		public void setSecu(String num) {
			secu.set(num);
		}

	}
	
	private void fillTable() throws SQLException {
		Statement stmt = ConnectToBDD.openConnection();
		Medecin med = new Medecin(stmt, SampleController.id);
		List<Patient> pats = med.getPatients(stmt);
		for(Patient pat : pats) {
			data.add(new Person(pat.getPrenom(),pat.getNom(),pat.getCategorieAge(),pat.getId()+""));
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		try {
			fillTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		firstNameCol.setMinWidth(200);
	    lastNameCol.setMinWidth(200);
	    ageCol.setMinWidth(200);
	    secuCol.setMinWidth(200);
	     
     	firstNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("firstName"));
		lastNameCol.setCellValueFactory(new PropertyValueFactory<Person, String>("lastName"));
		ageCol.setCellValueFactory(new PropertyValueFactory<Person, String>("age"));
		secuCol.setCellValueFactory(new PropertyValueFactory<Person, String>("secu"));
		
		table.setItems(data);
		}
	
	@FXML
    void searchButton(ActionEvent event) throws IOException {
		for(Person pers : data)
			if(pers.getFirstName().toLowerCase().equals(text_search.getText().toLowerCase()))
				//nextScene(event);
				table.getSelectionModel().select(pers);
    }

	@Override
	public void nextScene(ActionEvent event) throws IOException {
		Stage stage = (Stage) label.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("newordo.fxml"))));
		
	}

}