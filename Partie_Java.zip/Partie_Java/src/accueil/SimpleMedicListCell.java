package accueil;

import accueil.NewOrdoController.Medic;
import javafx.scene.control.ListCell;

public class SimpleMedicListCell extends ListCell<Medic>{
	
	@Override
	protected void updateItem(Medic item, boolean empty) {
		super.updateItem(item, empty);
		setText(null);
		if(!empty && item != null) {
			final String text = String.format("%s", item.getName());
			setText(text);
		}
	}
}
