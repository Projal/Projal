package accueil;

import donnees.Medicament;
import javafx.scene.control.ListCell;

public class SimpleMedicamentListCell extends ListCell<Medicament>{
	
	@Override
	protected void updateItem(Medicament item, boolean empty) {
		super.updateItem(item, empty);
		setText(null);
		if(!empty && item != null) {
			final String text = String.format("%s", item.getNom());
			setText(text);
		}
	}
}
