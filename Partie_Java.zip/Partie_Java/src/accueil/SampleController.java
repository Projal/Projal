package accueil;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import donnees.*;
import connection.*;

public class SampleController extends Controller implements Initializable{
	
	static int id;

	@FXML
	private Button insc_button;
	
    @FXML
    private TextField user_field;

    @FXML
    private AnchorPane square;

    @FXML
    private AnchorPane background;

    @FXML
    private Button co_buton;

    @FXML
    private PasswordField pswd_field;
    
    @FXML
    private Text mdp_inv;

    
    @FXML
    void insc_med() throws IOException {
    	nextScene(background, "newmedecin.fxml");
    }
    
    @FXML
    void make_login() throws SQLException, IOException {
    	ConnectToBDD.openConnection();
	    Statement stmt = ConnectToBDD.getStmt();
	    id = Integer.parseInt(user_field.getText());
	    Medecin medecin = new Medecin(stmt,id);
    	if(pswd_field.getText().equals(medecin.getMdp()))
    		nextScene(background, "accueil.fxml");
    	else
    		mdp_inv.setVisible(true);
    	
    	ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
    }
    
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		square.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle (KeyEvent event) {
				if(event.getCode() == KeyCode.ENTER)
					try {
						make_login();
					} catch (SQLException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
		});
		
	}
}