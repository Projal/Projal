package accueil;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

import donnees.*;
import connection.*;

public class SampleController implements Controller{
	
	static int id;

    @FXML
    private TextField user_field;

    @FXML
    private AnchorPane square;

    @FXML
    private AnchorPane background;

    @FXML
    private Button co_buton;

    @FXML
    private PasswordField pswd_field;
    
    @FXML
    private Text mdp_inv;

    @FXML
    void make_login(ActionEvent event) throws SQLException, IOException {
    	ConnectToBDD.openConnection();
	    Statement stmt = ConnectToBDD.getStmt();
	    id = Integer.parseInt(user_field.getText());
	    System.out.println(id);
	    Medecin medecin = new Medecin(stmt,id);
    	if(pswd_field.getText().equals(medecin.getMdp()))
    		nextScene(event);
    	else
    		mdp_inv.setVisible(true);
    	
    	ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
    }
    
    @FXML
	public void nextScene(ActionEvent event) throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("accueil.fxml"))));
	}
}