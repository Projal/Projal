package accueil;

import java.util.Date;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class NewOrdoController {

    @FXML
    private AnchorPane background;

    @FXML
    private Button prescrip_button;

    @FXML
    private String nom_maladie;

    @FXML
    private String nom_medic;

    @FXML
    private int dur_trait;

    @FXML
    void prescrire(ActionEvent event) {
    	enregistrer_traitement();
    }

	private void enregistrer_traitement() {
		int nb_jours = dur_trait;
		Date date_d = null;
		date_d.setTime(System.currentTimeMillis());
		Date date_f = null;
		date_f.setTime(System.currentTimeMillis()+ nb_jours);
	}
}