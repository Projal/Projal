package accueil;

import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.EventHandler;
import connection.ConnectToBDD;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.StringConverter;
import donnees.*;

public class NewOrdoController implements Initializable{
	
	@FXML
	private DatePicker date_f;

    @FXML
    private AnchorPane background;

    @FXML
    private Button prescrip_button;

    @FXML
    private String nom_maladie;

    @FXML
    private String nom_medic;

    @FXML
    private int dur_trait;
    
    @FXML
    private TableView<Medic> medic_table;
    
    @FXML
    private TableColumn<Medic, String> medic_ordo;
    
    @FXML
    private ComboBox<Medic> med_box = new ComboBox<Medic>();
    
    private ObservableList<Medic> data = FXCollections.observableArrayList();
    
    private ObservableList<Medic> ordo = FXCollections.observableArrayList();
    
    public static class Medic {

		private final SimpleStringProperty name;
		private final SimpleStringProperty molecule;
		private final SimpleStringProperty maladie;


		private Medic(String name, String molecule, String maladie) {
			this.name = new SimpleStringProperty(name);
			this.molecule = new SimpleStringProperty(molecule);
			this.maladie = new SimpleStringProperty(maladie);
		}


		public String getName() {
			return name.get();
		}


		public String getMolecule() {
			return molecule.get();
		}


		public String getMaladie() {
			return maladie.get();
		}
	}

    @FXML
    void prescrire(ActionEvent event) throws ParseException, SQLException {
    	enregistrer_traitement();
    }

	private void enregistrer_traitement() throws ParseException, SQLException {
		Instant instant = date_f.getValue().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
		Date date = Date.from(instant);
		System.out.println(date);
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			fillMedic();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
		medic_ordo.setCellValueFactory(new PropertyValueFactory<Medic, String>("medic_ordo"));
		
		med_box.getItems().addAll(data);
		med_box.setCellFactory(listView -> new SimpleMedicListCell());
		med_box.setConverter(new StringConverter<Medic>() {
			
			@Override
			public String toString(Medic object) {
				if(object == null)
					return "";
				return object.getName();
			}
			
			@Override
			public Medic fromString(String string) {
				return new Medic(string, null, null);
			}
		});
		
		med_box.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle (KeyEvent event) {
				if(event.getCode() == KeyCode.ENTER)
					try {
						addMedic();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		});
		
		FxUtilTest.autoCompleteComboBoxPlus(med_box, (typedText, itemToCompare) -> 
			itemToCompare.getName().toLowerCase().contains(typedText.toLowerCase()));
		FxUtilTest.getComboBoxValue(med_box);
	
	}
	
	private void fillMedic() throws SQLException{
		Statement stmt = ConnectToBDD.openConnection();
		Medicament medic = new Medicament(stmt);
		List<Medicament> meds = medic.getMedic(stmt);
		Collections.sort(meds, new Comparator<Medicament>() {
			@Override
			public int compare(Medicament med1, Medicament med2) {
				return med1.getNom().compareTo(med2.getNom());
			}
		});
		for(Medicament med : meds) {
			data.add(new Medic(med.getNom(), null, null));
		}
	}

	private void addMedic() throws SQLException {
		for(Medic med : data)
			if(med.equals(data.get(0))) {
				ordo.add(med);
				medic_table.setItems(ordo);
				System.out.println(medic_table.getItems().toString());
			}
				//System.out.println(med.equals(data.get(0)));
			//data.get(dur_trait).getName();
		
	}
}