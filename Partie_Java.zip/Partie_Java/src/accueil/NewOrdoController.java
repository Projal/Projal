package accueil;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.EventHandler;
import connection.ConnectToBDD;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.StringConverter;
import donnees.*;

public class NewOrdoController implements Initializable{
	
	
    @FXML
    private AnchorPane background;
    
    @FXML
    private Button prescrip_button;
    
    @FXML
    private Button prescrip_button1;

    @FXML
    private String nom_maladie;

    @FXML
    private String nom_medic;
    
    @FXML
    private Button return_button;

    @FXML
    private TextArea fiche_pat;
    
    @FXML
    private TableView<Medic> medic_table;
    
    @FXML
    private TableColumn<Medic, String> medic_ordo;
    
    @FXML
    private ComboBox<Medic> med_box = new ComboBox<Medic>();
    
    @FXML
    private Text nom = new Text();
    
    @FXML
    private Text prenom = new Text();

    @FXML
    private Text age = new Text();

    @FXML
    private Text secu = new Text();
    
    @FXML
    private TextFlow traitements;

    @FXML
    private TextFlow contreIndic;

    
    private ObservableList<Medic> data = FXCollections.observableArrayList();
    
    private ObservableList<Medic> ordo = FXCollections.observableArrayList();
    
    private ObservableList<Text> contr = FXCollections.observableArrayList();
    
    private ObservableList<Text> trait = FXCollections.observableArrayList();
    
    public static class Medic {

		private final SimpleStringProperty name;

		private Medic(String name) {
			this.name = new SimpleStringProperty(name);
		}

		public String getName() {
			return name.get();
		}
	}

    @FXML
    void prescrire(ActionEvent event) throws ParseException, SQLException {
    	enregistrer_traitement();
    }

	private void enregistrer_traitement() throws ParseException, SQLException {
		
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		try {
			fillMedic();
			fillFiche();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}		
		
		medic_ordo.setMinWidth(50);
		medic_ordo.setCellValueFactory(new PropertyValueFactory<Medic, String>("name"));
		
		med_box.getItems().addAll(data);
		med_box.setCellFactory(listView -> new SimpleMedicListCell());
		med_box.setConverter(new StringConverter<Medic>() {
			
			@Override
			public String toString(Medic object) {
				if(object == null)
					return "";
				return object.getName();
			}
			
			@Override
			public Medic fromString(String string) {
				return new Medic(string);
			}
		});
		
		med_box.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle (KeyEvent event) {
				if(event.getCode() == KeyCode.ENTER)
					try {
						addMedic();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		});
		
		FxUtilTest.autoCompleteComboBoxPlus(med_box, (typedText, itemToCompare) -> 
			itemToCompare.getName().toLowerCase().contains(typedText.toLowerCase()));
		FxUtilTest.getComboBoxValue(med_box);
	}
	
	private void fillMedic() throws SQLException{
		ConnectToBDD.openConnection();
	    Statement stmt = ConnectToBDD.getStmt();
		Medicament medic = new Medicament(stmt);
		List<Medicament> meds = medic.getMedic(stmt);
		Collections.sort(meds, new Comparator<Medicament>() {
			@Override
			public int compare(Medicament med1, Medicament med2) {
				return med1.getNom().compareTo(med2.getNom());
			}
		});
		for(Medicament med : meds) {
			data.add(new Medic(med.getNom()));
		}
		ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
	}
	
	private void fillFiche() throws SQLException, ParseException{
		ConnectToBDD.openConnection();
	    Statement stmt = ConnectToBDD.getStmt();
		Patient pat = new Patient(AccueilController.pers.getSecu(), AccueilController.pers.getLastName(), AccueilController.pers.getFirstName(), AccueilController.pers.getCategorieAge());
		pat.addContreIndication(new ContreIndication(stmt, "grossesse\n"));
		pat.addContreIndication(new ContreIndication(stmt, "allergie"));
		List<Medicament> medic = new Medicament(stmt).getMedic(stmt);
		List<String> str = new ArrayList<String>();
		for(Medicament med : medic) {
			// YA1PBICI  str.add(med.);
		}
		pat.addTraitement(new Traitement(new Date(System.currentTimeMillis()), new Date(System.currentTimeMillis()), str, 3, stmt));
		nom.setText(pat.getNom());
		prenom.setText(pat.getPrenom());
		age.setText(pat.getCategorieAgeString());
		secu.setText(pat.getId() +"");
		for(ContreIndication list : pat.getContreIndications()) {
			contr.add(new Text(list.getNom()));
		}
		contreIndic.getChildren().addAll(contr);
		
		for(Traitement traite : pat.getTraitements()) {
			trait.add(new Text(traite.getMaladie(stmt)));
		}
		traitements.getChildren().addAll(trait);
		
	}

	@FXML
	private void addMedic() throws SQLException {
		if(!med_box.getEditor().getText().isEmpty()) {
			medic_ordo.setVisible(true);
			ordo.add(new Medic(med_box.getEditor().getText()));
			medic_table.getItems().addAll(new Medic(med_box.getEditor().getText()));
			System.out.println(med_box.getEditor().getText());
		}
	}
	
	@FXML
	private void returnButton() throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("accueil.fxml"))));
	}
	
	@FXML
	private void nextScene(ActionEvent e) throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("solution.fxml"))));
	}
}