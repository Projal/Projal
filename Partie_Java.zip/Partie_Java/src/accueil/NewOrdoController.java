package accueil;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;

import algorithme.Algorithme;
import connection.ConnectToBDD;
import donnees.ContreIndication;
import donnees.Maladie;
import donnees.Medecin;
import donnees.Medicament;
import donnees.Patient;
import donnees.Traitement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.StringConverter;

public class NewOrdoController extends Controller implements Initializable{

	@FXML
    private AnchorPane background;
    
    @FXML
    private Button prescrip_button;
    
    @FXML
    private TextField duree_trait;

    @FXML
    private String nom_medic;
    
    @FXML
    private Button return_button;

    @FXML
    private TextArea fiche_pat;
    
    @FXML
    private TableView<Medicament> medic_table;
    
    @FXML
    private TableColumn<Medicament, String> medic_ordo;
    
    @FXML
    private ComboBox<Medicament> med_box = new ComboBox<Medicament>();
    
    @FXML
    private Text nom = new Text();
    
    @FXML
    private Text prenom = new Text();

    @FXML
    private Text age = new Text();

    @FXML
    private Text secu = new Text();
    
    @FXML
    private TextFlow traitements;

    @FXML
    private TextFlow contreIndic;
    
    @FXML
    private Label trait_valide;

    @FXML
    private Button enreg_trait;
    
    @FXML
    private Button verif_trait;
    
    @FXML
    private Button retir_trait;
    
    private ObservableList<Medicament> data = FXCollections.observableArrayList();
    
    private ObservableList<Medicament> ordo = FXCollections.observableArrayList();
    
    private ObservableList<Text> contr = FXCollections.observableArrayList();
    
    private ObservableList<Text> trait = FXCollections.observableArrayList();

    @FXML
	private Text duree_champ;

    @FXML
	private TextField maladie;

    @FXML
	private Text maladie_champ;

    @FXML
	private Text mal_inval;
    
    @FXML
    void retirer_medic() {
    	if(!medic_table.getSelectionModel().isEmpty()) {
			ordo.remove(medic_table.getSelectionModel().getSelectedIndex());
			medic_table.getItems().remove(medic_table.getSelectionModel().getSelectedIndex());
			medic_table.refresh();
		}
    }
    
    @FXML
    void retour() throws IOException {
    	if(NewPatientController.fromPatient)
    		nextScene(background, "newpatient.fxml");
    	else
    		nextScene(background, "accueil.fxml");
    }

    @FXML
	private void verifier_traitement() throws ParseException, SQLException, IOException {
		List<Medicament> solution = Algorithme.Algo(ordo, AccueilController.pers);
		if(duree_trait.getText().isEmpty())
    		duree_champ.setVisible(true);
    	else duree_champ.setVisible(false);
    	if(maladie.getText().isEmpty())
    		maladie_champ.setVisible(true);
    	else maladie_champ.setVisible(false);
		if(ordo.equals(solution)) {
			trait_valide.setVisible(true);
			enreg_trait.setVisible(true);
		}
		else
			nextScene(background,"solution.fxml");
	}
    
    @FXML
    private void enregistrer_traitement() throws NumberFormatException, SQLException, ParseException {
    	Medecin med = new Medecin(ConnectToBDD.getStmt(),SampleController.id);
    	Patient pat;
    	int id_pat = Patient.patientExistant(Integer.parseInt(secu.getText()), ConnectToBDD.getStmt());
    	Maladie mal = new Maladie(ConnectToBDD.getStmt(),maladie.getText());
    	if(mal.getId() < 0) {
    		mal_inval.setVisible(true);
    		return;
    	}
    	List<String> nom_meds = new ArrayList<String>();
    	Traitement trait = new Traitement(new Date(System.currentTimeMillis()),
				new Date(System.currentTimeMillis()+Long.parseLong(duree_trait.getText())*86400000),nom_meds,mal.getId(), ConnectToBDD.getStmt());
    	if(id_pat != -1)
    		pat = med.getPatients(ConnectToBDD.getStmt()).get(id_pat);
    	else
    		pat = new Patient(Long.parseLong(secu.getText()),nom.getText(),prenom.getText(),age.getText());
    	pat.addTraitement(trait);
    	med.prescription(id_pat, trait.getId(), ConnectToBDD.getStmt());
    }

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			fillMedic();
			if(NewPatientController.fromPatient)
				fillFiche(NewPatientController.pers);
			else if(AccueilController.fromAccueil)
				fillFiche(AccueilController.pers);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}		
		
		medic_ordo.setMinWidth(50);
		medic_ordo.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom"));
		
		med_box.getItems().addAll(data);
		med_box.setCellFactory(listView -> new SimpleMedicamentListCell());
		med_box.setConverter(new StringConverter<Medicament>() {
			
			@Override
			public String toString(Medicament object) {
				if(object == null)
					return "";
				return object.getNom();
			}
			
			@Override
			public Medicament fromString(String string){
				try {
					return new Medicament(ConnectToBDD.getStmt(),string);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return null;
			}
		});
		
		med_box.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle (KeyEvent event) {
				if(event.getCode() == KeyCode.ENTER)
					try {
						addMedic();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		});
		medic_table.setOnKeyPressed(new EventHandler<KeyEvent>(){
			@Override
			public void handle(KeyEvent event) {
				if(event.getCode() == KeyCode.BACK_SPACE || event.getCode() == KeyCode.DELETE)
					retirer_medic();
			}
		});
		
		FxUtilTest.autoCompleteComboBoxPlus(med_box, (typedText, itemToCompare) -> 
			itemToCompare.getNom().toLowerCase().contains(typedText.toLowerCase()));
		FxUtilTest.getComboBoxValue(med_box);
	}
	
	private void fillMedic() throws SQLException{
		ConnectToBDD.openConnection();
	    Statement stmt = ConnectToBDD.getStmt();
		List<Medicament> meds = Medicament.getMedic(stmt);
		Collections.sort(meds, new Comparator<Medicament>() {
			@Override
			public int compare(Medicament med1, Medicament med2) {
				return med1.getNom().compareTo(med2.getNom());
			}
		});
		for(Medicament med : meds) {
			data.add(med);
		}
		ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
	}
	
	private void fillFiche(Patient pers) throws SQLException, ParseException{
		ConnectToBDD.openConnection();
		Patient pat = new Patient(pers.getId(), pers.getNom(), pers.getPrenom(), pers.getCategorieAge());
		nom.setText(pat.getNom());
		prenom.setText(pat.getPrenom());
		age.setText(pat.getCategorieAge());
		secu.setText(pat.getId() +"");
		for(ContreIndication list : pat.getContreIndications()) {
			contr.add(new Text(list.getNom()+"\n"));
		}
		contreIndic.getChildren().addAll(contr);
		for(Traitement traite : pat.getTraitements()) {
			List<String> medNames = new ArrayList<String>();
			for(Medicament medoc : traite.getListMedicaments()) {
				if(!medNames.contains(medoc.getNom()+"\n")) {
					trait.add(new Text(medoc.getNom()+"\n"));
					medNames.add(medoc.getNom()+"\n");
				}
			}
		}
		traitements.getChildren().addAll(trait);
	}

	@FXML
	private void addMedic() throws SQLException {
		if(!med_box.getEditor().getText().isEmpty()) {
			medic_ordo.setVisible(true);
			if(Medicament.medicamentExistant(ConnectToBDD.getStmt(), med_box.getEditor().getText().toString())) {
				ordo.add(new Medicament(ConnectToBDD.getStmt(),med_box.getEditor().getText().toString()));
				medic_table.getItems().addAll(new Medicament(ConnectToBDD.getStmt(),med_box.getEditor().getText().toString()));
			}
		}
	}
}