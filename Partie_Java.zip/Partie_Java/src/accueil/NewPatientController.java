package accueil;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

import connection.ConnectToBDD;
import donnees.Patient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class NewPatientController {

    @FXML
    private TextArea traitement_txt;

    @FXML
    private TextField pren_txt;

    @FXML
    private TextField catage_txt;

    @FXML
    private Button enregistrer_button;
    
    @FXML
    private Button retour_button;

    @FXML
    private AnchorPane background;

    @FXML
    private TextField nom_txt;

    @FXML
    private TextArea contreindic_txt;

    @FXML
    private TextField secu_txt;
    
    @FXML
    private Text nom_champ;

    @FXML
    private Text prenom_champ;

    @FXML
    private Text secu_champ;

    @FXML
    private Text cat_champ;
    
    @FXML
    private ComboBox<String> catage_box;

    
    
    @FXML
    void enregistrer_patient(ActionEvent event) throws NumberFormatException, SQLException, IOException {
    	if(nom_txt.getText().isEmpty())
    		nom_champ.setVisible(true);
    	else nom_champ.setVisible(false);
    	if(pren_txt.getText().isEmpty())
    		prenom_champ.setVisible(true);
    	else prenom_champ.setVisible(false);
    	if(catage_txt.getText().isEmpty())
    		cat_champ.setVisible(true);
    	else cat_champ.setVisible(false);
    	if(secu_txt.getText().isEmpty())
    		secu_champ.setVisible(true);
    	else secu_champ.setVisible(false);
		if(!nom_champ.isVisible() && !prenom_champ.isVisible() && !cat_champ.isVisible() && !secu_champ.isVisible()) {
		    Statement stmt = ConnectToBDD.getStmt();
	    	createNewPatient(stmt);
	    	ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
		}
		//nextScene(event);
    }
    
    public int getSecuToInt() {
    	if(secu_txt.getText().isEmpty())
    		return -1;
    	return Integer.parseInt(secu_txt.getText());
    }
    
    public int getCatToInt() {
    	if(catage_txt.getText().isEmpty()) 
    		return -1;
    	return Integer.parseInt(catage_txt.getText());
    }
    
    public void createNewPatient(Statement stmt) throws NumberFormatException, SQLException {
		new Patient(stmt, getSecuToInt(), nom_txt.getText(), pren_txt.getText(), getCatToInt());
    }
    
    @FXML
	private void returnButton() throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("accueil.fxml"))));
	}

    private void nextScene(ActionEvent e) throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("accueil.fxml"))));
	}
}