package accueil;

import java.net.URL;
import java.util.ResourceBundle;

import donnees.Medicament;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
public class SolutionController implements Initializable {
	
    @FXML
    private Button remplacer_button;

    @FXML
    private TableView<Medicament> tab_rempl;

    @FXML
    private AnchorPane background;

    @FXML
    private TableColumn<Medicament, String> nom_medicIncomp;

    @FXML	
    private TableColumn<Medicament, String> nom_medicRempl;

    @FXML
    private TableView<Medicament> tab_incomp;

    @FXML
    void remplacer_medic(ActionEvent event) {

    }

    
	private final ObservableList<Medicament> data = FXCollections.observableArrayList(NewOrdoController.solution);

    
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
	    
		nom_medicIncomp.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom"));
     	nom_medicRempl.setCellValueFactory(new PropertyValueFactory<Medicament, String>("nom"));

		tab_rempl.setItems(data);
		}

}