package accueil;

import donnees.Maladie;
import javafx.scene.control.ListCell;

public class SimpleMaladieListCell extends ListCell<Maladie>{
	
	@Override
	protected void updateItem(Maladie item, boolean empty) {
		super.updateItem(item, empty);
		setText(null);
		if(!empty && item != null) {
			final String text = String.format("%s", item.getNom());
			setText(text);
		}
	}
}
