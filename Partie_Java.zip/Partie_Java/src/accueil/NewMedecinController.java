package accueil;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

import connection.ConnectToBDD;
import donnees.Medecin;
import donnees.Patient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

public class NewMedecinController {

    @FXML
    private TextField id_text;

    @FXML
    private Button inscription_button;

    @FXML
    private AnchorPane background;

    @FXML
    private TextField nom_text;

    @FXML
    private TextField mail_text;

    @FXML
    private TextField prenom_text;

    @FXML
    private TextField motdepasse;

    @FXML
    private TextField conf_motdepasse;

    @FXML
	private Text nom_champ;

    @FXML
	private Text prenom_champ;

    @FXML
	private Text mail_champ;

    @FXML
	private Text mdp_champ;

    @FXML
	private Text id_champ;

    @FXML
	private Text conf_motdepasse_champ;

    @FXML
    void inscrire_medecin(ActionEvent event) throws NumberFormatException, SQLException, IOException{
    	ConnectToBDD.openConnection();
    	if(nom_text.getText().isEmpty())
    		nom_champ.setVisible(true);
    	else nom_champ.setVisible(false);
    	if(prenom_text.getText().isEmpty())
    		prenom_champ.setVisible(true);
    	else prenom_champ.setVisible(false);
    	if(id_text.getText().isEmpty())
    		id_champ.setVisible(true);
    	else id_champ.setVisible(false);
    	if(mail_text.getText().isEmpty())
    		mail_champ.setVisible(true);
    	else mail_champ.setVisible(false);
    	if(motdepasse.getText().isEmpty())
    		mdp_champ.setVisible(true);
    	else mdp_champ.setVisible(false);
    	if(conf_motdepasse.getText().isEmpty())
    		conf_motdepasse_champ.setVisible(true);
    	else conf_motdepasse_champ.setVisible(false);
		if(!nom_champ.isVisible() && !prenom_champ.isVisible() && !mail_champ.isVisible() && !id_champ.isVisible() && !mdp_champ.isVisible() && !conf_motdepasse_champ.isVisible()) {
		    Statement stmt = ConnectToBDD.getStmt();
	    	createNewMedecin(stmt);
	    	ConnectToBDD.closeConnection(null, stmt, stmt.getConnection());
	    	
		}
    }
    
    
    public int getIdToInt() {
    	if(id_text.getText().isEmpty())
    		return -1;
    	return Integer.parseInt(id_text.getText());
    }
    
    public void createNewMedecin(Statement stmt) throws NumberFormatException, SQLException {
    	if(motdepasse.getText().length() < 8)
    		
		new Medecin(stmt, getIdToInt(), mail_text.getText(), motdepasse.getText(), nom_text.getText(), prenom_text.getText());
    }

}
