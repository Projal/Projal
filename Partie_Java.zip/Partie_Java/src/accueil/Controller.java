package accueil;

import java.io.IOException;

import javafx.event.ActionEvent;

public interface Controller {

	public void nextScene(ActionEvent event) throws IOException;
}
