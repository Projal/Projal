package accueil;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public abstract class Controller {


	void nextScene(AnchorPane background, String nextscene) throws IOException {
		Stage stage = (Stage) background.getScene().getWindow();
		stage.setScene(new Scene(FXMLLoader.load(getClass().getResource(nextscene))));
	}
}
